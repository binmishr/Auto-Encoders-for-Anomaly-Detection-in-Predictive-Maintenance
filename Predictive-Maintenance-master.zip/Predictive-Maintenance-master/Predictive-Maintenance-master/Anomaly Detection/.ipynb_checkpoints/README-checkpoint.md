### Anomaly Detection in Predictive Maintenance
Fault detection is the primary step of predictive maintenance where the machine’s health data is used to determine if the machine is operating in the normal or abnormal condition. This process is often referred to as anomaly detection or outlier detection in machine learning. Anomaly detections are used applications such as banking for anomaly detection, video and image analytics, network security and intrusion detection. 

### Models
In this repo I have various models added for performing anomaly detection such as PCA-T2/PCA-SPE, K-Means, Auto Encoders, and Gaussian Mixture modeling. There are more models that could be used and will be added soon

### Citation Information
If you are using any of the following information, please use it and cite the authors because that's a nice thing to do. 

