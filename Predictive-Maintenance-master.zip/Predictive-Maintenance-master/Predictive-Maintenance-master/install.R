install.packages(c("qcc","caret", "foreach", "dplyr", "h2o", "doParallel", "ModelMetrics", "mclust", "e1071","imports","randomForest", "keras" ), dependencies=TRUE)
install.packages('https://cran.r-project.org/src/contrib/mdatools_0.9.1.tar.gz')
